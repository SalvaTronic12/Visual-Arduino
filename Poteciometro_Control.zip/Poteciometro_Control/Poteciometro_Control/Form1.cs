﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO.Ports;

namespace Poteciometro_Control
{
    public partial class Form1 : Form
    {
        SerialPort puertoAr;
       
        public Form1()
        {
            InitializeComponent();
            puertoAr = new SerialPort();
            puertoAr.PortName = "COM8";
            puertoAr.BaudRate = 9600;
            puertoAr.DtrEnable = true;
            try
            {
                puertoAr.Open();
            }
            catch (Exception)
            {
                MessageBox.Show("QUE DEBE CONECTAR EL ARDUINO PARA LA TRANSICION DE DATOS");
            }
         
           
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            timer1.Enabled = true;
        }

        private void timer1_Tick(object sender, EventArgs e)
        {
            String valor = puertoAr.ReadLine();
            datos.Text = valor;

            int valorPot;

            try
            {
                valorPot = Convert.ToInt32(valor);
                progressBar1.Value = valorPot;
            }
            catch { }
        }
    } 
}
